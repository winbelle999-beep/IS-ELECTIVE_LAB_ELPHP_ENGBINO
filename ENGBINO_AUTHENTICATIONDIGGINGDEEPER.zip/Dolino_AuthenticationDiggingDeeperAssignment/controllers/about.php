<?php

$heading = 'About Us';

require "views/about.view.php";