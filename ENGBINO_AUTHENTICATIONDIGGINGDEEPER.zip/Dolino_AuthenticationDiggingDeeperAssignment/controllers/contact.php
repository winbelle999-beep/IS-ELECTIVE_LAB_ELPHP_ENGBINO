<?php

$heading = 'Contact Us';

require "views/contact.view.php";