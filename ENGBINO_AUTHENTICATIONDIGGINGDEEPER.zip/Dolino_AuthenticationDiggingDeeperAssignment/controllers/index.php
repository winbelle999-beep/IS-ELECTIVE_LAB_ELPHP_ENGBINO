<?php

$heading = "Home";

require "views/index.view.php";