<?php require 'partials/header.php'?>
<?php require 'partials/nav.php' ?>

    <h2>Our culture at <?= $website; ?></h2>
    <p>This is the <strong> <?php echo basename($_SERVER['PHP_SELF'])?></strong> page content.</p>

<?php require 'partials/footer.php'?>