<!DOCTYPE html>
<html lang="en">
<body>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>My Document</title>

    <style>
        * {
            background: black;
            color: white;
        }
        h3 {
            color: orange;
        }

        hr {
            border-color: #fed8b1;
        }
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }
        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        tr:nth-child(even) {
            background-color: #dddddd;
        }
    </style>
</head>