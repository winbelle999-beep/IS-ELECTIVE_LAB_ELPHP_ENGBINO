</body>
<hr>
<h2>The footer begins here</h2>
</html>