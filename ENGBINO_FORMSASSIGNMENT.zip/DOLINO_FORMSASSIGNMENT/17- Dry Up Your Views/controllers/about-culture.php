<?php

$website = 'Jonathan';

require 'views/about-culture.view.php';
