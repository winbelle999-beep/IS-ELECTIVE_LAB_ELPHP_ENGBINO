1. Create your own local database as per [this](/11-%20MySql/index.sql) guideline or by watching [this](https://laracasts.com/series/php-for-beginners/episodes/11) video.
2. Clone the repository and save locally.
3. Run the server within this folder.

![Database visualization](/Screenshots/db-visualization.png)

