<?php

require 'views/about-culture.view.php';
