<?php

var_dump('You typed ' . $_POST['name']);

// var_dump($app['database']); 
