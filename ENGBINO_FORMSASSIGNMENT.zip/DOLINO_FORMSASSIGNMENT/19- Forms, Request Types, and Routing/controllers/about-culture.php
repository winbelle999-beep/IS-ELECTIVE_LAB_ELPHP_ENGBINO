<?php

$website = 'example.com';

require 'views/about-culture.view.php';
