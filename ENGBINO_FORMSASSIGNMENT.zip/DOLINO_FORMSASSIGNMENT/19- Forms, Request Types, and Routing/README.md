1. Create your own local database as per [this](/11-%20MySql/index.sql) guideline or watching [this](https://laracasts.com/series/php-for-beginners/episodes/11) video.
2. Clone the repository and save locally.
3. Run the server in this folder.

![Database visualization](https://media.giphy.com/media/U7W0LJVuP4AXr3qzP9/giphy.gif)
