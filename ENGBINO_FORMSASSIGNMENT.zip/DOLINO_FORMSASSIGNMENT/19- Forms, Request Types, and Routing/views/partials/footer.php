</body>
<hr>
<h3>Your footer</h3>

</html>